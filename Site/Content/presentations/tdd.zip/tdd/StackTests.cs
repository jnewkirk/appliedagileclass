﻿using System;
using Xunit;

public class StackTests
{
    public class EmptyStackTests
    {
        [Fact]
        public void Count_IsZero()
        {
            Stack<string> stack = new Stack<string>();

            int count = stack.Count;

            Assert.Equal(0, count);
        }

        [Fact]
        public void Pop_Throws()
        {
            Stack<string> stack = new Stack<string>();

            Exception exception =
                Record.Exception(() => stack.Pop());

            Assert.IsType<InvalidOperationException>(exception);
        }

        [Fact]
        public void Peek_Throws()
        {
            Stack<string> stack = new Stack<string>();

            Exception exception =
                Record.Exception(() => stack.Peek());

            Assert.IsType<InvalidOperationException>(exception);
        }        
    }

    [Fact]
    public void Push_CountIsOne()
    {
        Stack<string> stack = new Stack<string>();
        stack.Push("Class");

        int count = stack.Count;

        Assert.Equal(1, count);
    }

    [Fact]
    public void PushPop_CountIsZero()
    {
        Stack<string> stack = new Stack<string>();
        stack.Push("Class");
        stack.Pop();

        int count = stack.Count;

        Assert.Equal(0, count);
    }

    [Fact]
    public void PushPeek_CountIsOne()
    {
        Stack<string> stack = new Stack<string>();
        stack.Push("Class");
        stack.Peek();

        int count = stack.Count;

        Assert.Equal(1, count);
    }

    [Fact]
    public void PushNull_PeekIsNull()
    {
        Stack<string> stack = new Stack<string>();
        stack.Push(null);
        
        string actual = stack.Peek();

        Assert.Null(actual);
    }

    [Fact]
    public void PushClass_PopIsClass()
    {
        Stack<string> stack = new Stack<string>();
        stack.Push("Class");

        string actual = stack.Pop();

        Assert.Equal("Class", actual);
    }

    [Fact]
    public void PushElements_PopLIFOOrder()
    {
        Stack<string> stack = new Stack<string>();
        stack.Push("Class");
        stack.Push("Saturday");

        string actual = stack.Pop();
        Assert.Equal("Saturday", actual);

        actual = stack.Pop();
        Assert.Equal("Class", actual);
    }

    [Fact]
    public void PushIntegerElements_PopLIFOOrder()
    {
        Stack<int> stack = new Stack<int>();
        stack.Push(12);
        stack.Push(3);

        int actual = stack.Pop();
        Assert.Equal(3, actual);

        actual = stack.Pop();
        Assert.Equal(12, actual);
    }
}

