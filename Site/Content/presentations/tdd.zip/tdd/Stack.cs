﻿
using System;
using System.Collections.Generic;

public class Stack<T>
{
    private List<T> elements = new List<T>();

    public int Count
    {
        get { return elements.Count; }
    }

    public void Push(T element)
    {
        elements.Add(element);
    }

    public T Pop()
    {
        T element = Peek();

        elements.RemoveAt(elements.Count - 1);
        return element;
    }

    public T Peek()
    {
        if (elements.Count == 0)
            throw new InvalidOperationException();

        return elements[elements.Count - 1];
    }
}



