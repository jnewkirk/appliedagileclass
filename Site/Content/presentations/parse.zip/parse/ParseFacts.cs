﻿using System;
using Xunit;
using Xunit.Extensions;

public class ParseFacts
{
    public class Guards
    {
        [Fact]
        public void ParseWithNull_ThrowsArgumentNullException()
        {
            Exception exception = Record.Exception(
                () => Int32.Parse(null));

            ArgumentNullException argumentException = 
                Assert.IsType<ArgumentNullException>(exception);
            Assert.Equal("String", argumentException.ParamName);
        }

        [Fact]
        public void ParseWithInvalidFormat_ThrowsFormatException()
        {
            Exception exception = Record.Exception(
                () => Int32.Parse("abc"));

            FormatException formatException =
                Assert.IsType<FormatException>(exception);
            Assert.Equal("Input string was not in a correct format.", 
                         formatException.Message);
        }

        [Fact]
        public void ParseWithLessThanInt32MinValue_ThrowsOverflowException()
        {
            Exception exception = Record.Exception(
                () => Int32.Parse(Int64.MinValue.ToString()));

            OverflowException overflowException =
                Assert.IsType<OverflowException>(exception);
            Assert.Equal("Value was either too large or too small for an Int32.",
                         overflowException.Message);
        }

        [Fact]
        public void ParseWithGreaterThanInt32MaxValue_ThrowsOverflowException()
        {
            Exception exception = Record.Exception(
                () => Int32.Parse(Int64.MaxValue.ToString()));

            OverflowException overflowException =
                Assert.IsType<OverflowException>(exception);
            Assert.Equal("Value was either too large or too small for an Int32.",
                         overflowException.Message);
        }
    }

    public class ParsePositiveNumbers
    {
        [Fact]
        public void Int32ParsePositiveNumber_Success()
        {
            int actualValue = Int32.Parse("42");

            Assert.Equal(42, actualValue);
        }

        [Theory]
        [InlineData("12", 12)]
        [InlineData("   42", 42)]
        [InlineData("+42", 42)]
        [InlineData("  +42", 42)]
        [InlineData("+42   ", 42)]
        [InlineData("42    ", 42)]
        [InlineData("   +42   ", 42)]
        public void Int32Parse_Success(string parseString, int expectedValue)
        {
            int actualValue = Int32.Parse(parseString);
 
            Assert.Equal(expectedValue, actualValue);
        }
    }
}
