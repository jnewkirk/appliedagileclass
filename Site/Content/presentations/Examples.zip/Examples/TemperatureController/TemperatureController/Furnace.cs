﻿public interface IFurnace
{
    void On();
}

public class Furnace : IFurnace
{
    public void On()
    {
        // turn on the furnace
    }
}
