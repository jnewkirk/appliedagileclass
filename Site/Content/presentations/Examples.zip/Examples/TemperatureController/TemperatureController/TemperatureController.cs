﻿public class TemperatureController
{
	IAirConditioner airConditioner;
    IFurnace furnace; 
	ITemperatureSensor sensor;

    public TemperatureController() :
        this(new AirConditioner(), new Furnace(), new TemperatureSensor())
    {}


    // only for testing
    public TemperatureController(
        IAirConditioner airConditioner,
        IFurnace furnace,
        ITemperatureSensor sensor)
    {
        this.airConditioner = airConditioner;
        this.furnace = furnace;
        this.sensor = sensor; 
    }

    public void AdjustTemperature(int requiredTemperature)
    {
        if (requiredTemperature < CurrentTemperature)
            airConditioner.On();
        else if (requiredTemperature > CurrentTemperature)
            furnace.On(); 
    }

    public int CurrentTemperature
    {
        get { return sensor.CurrentTemperature; }
    }
}
