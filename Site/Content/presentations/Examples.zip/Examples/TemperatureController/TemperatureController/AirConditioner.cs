﻿public interface IAirConditioner
{
    void On();
}

public class AirConditioner : IAirConditioner
{
    public void On()
    {
        // turn on the air conditioner
    }
}

