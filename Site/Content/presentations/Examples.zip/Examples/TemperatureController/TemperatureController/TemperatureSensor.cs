﻿public interface ITemperatureSensor
{
    int CurrentTemperature { get; set; }
}

public class TemperatureSensor : ITemperatureSensor
{
    public virtual int CurrentTemperature
    {
        get
        {
            // call the sensor to retrieve the current temperature
            return 0; 
        }
        set
        {
            throw new System.NotImplementedException();
        }
    }
}

