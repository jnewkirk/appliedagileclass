﻿using Global.Fakes;
using Microsoft.QualityTools.Testing.Fakes;
using Xunit;

public class CharacterizationTests
{
    [Fact]
    public void AdjustTemperature_ShouldCallAirConditionerOn()
    {
        using (ShimsContext.Create())
        {
            ShimTemperatureSensor.AllInstances.CurrentTemperatureGet = self => 78;

            var onCalled = false;
            ShimAirConditioner.AllInstances.On = self => onCalled = true;

            TemperatureController temperatureController = new TemperatureController();

            temperatureController.AdjustTemperature(75);

            Assert.True(onCalled);
        }
    }

    [Fact]
    public void AdjustTemperature_ShouldNotCallAirConditionerOn()
    {
        using (ShimsContext.Create())
        {
            ShimTemperatureSensor.AllInstances.CurrentTemperatureGet = self => 73;

            var onCalled = false;
            ShimAirConditioner.AllInstances.On = self => onCalled = true;

            TemperatureController temperatureController = new TemperatureController();

            temperatureController.AdjustTemperature(75);

            Assert.False(onCalled);
        }
    }

    [Fact]
    public void AdjustTemperature_ShouldCallFurnaceOn()
    {
        using (ShimsContext.Create())
        {
            ShimTemperatureSensor.AllInstances.CurrentTemperatureGet = self => 73;

            var onCalled = false;
            ShimFurnace.AllInstances.On = self => onCalled = true;

            TemperatureController temperatureController = new TemperatureController();

            temperatureController.AdjustTemperature(75);

            Assert.True(onCalled);
        }
    }

    [Fact]
    public void AdjustTemperature_ShouldNotCallFurnaceOn()
    {
        using (ShimsContext.Create())
        {
            ShimTemperatureSensor.AllInstances.CurrentTemperatureGet = self => 75;

            var onCalled = false;
            ShimFurnace.AllInstances.On = self => onCalled = true;

            TemperatureController temperatureController = new TemperatureController();

            temperatureController.AdjustTemperature(73);

            Assert.False(onCalled);
        }
    }
}

