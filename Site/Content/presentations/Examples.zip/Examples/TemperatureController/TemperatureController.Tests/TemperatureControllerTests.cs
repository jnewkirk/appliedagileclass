﻿using Moq;
using Xunit;

public class TemperatureControllerTests
{
    [Fact]
    public void AdjustTemperature_ShouldNotCallAirConditionerOn()
    {
        var stubSensor = new Mock<ITemperatureSensor>();
        stubSensor.SetupProperty(x => x.CurrentTemperature, 73);

        var stubAirConditioner = new Mock<IAirConditioner>();
        var stubFurnace = new Mock<IFurnace>();

        TemperatureController temperatureController =
            new TemperatureController(stubAirConditioner.Object,
                                      stubFurnace.Object,
                                      stubSensor.Object);

        temperatureController.AdjustTemperature(75);

        stubAirConditioner.Verify(x => x.On(), Times.Never());
    }


    [Fact]
    public void AdjustTemperature_ShouldCallAirConditionerOn()
    {
        var stubSensor = new Mock<TemperatureSensor>();
        stubSensor.SetupProperty(x => x.CurrentTemperature, 75);

        var stubAirConditioner = new Mock<IAirConditioner>();
        var stubFurnace = new Mock<IFurnace>();

        TemperatureController temperatureController = new
            TemperatureController(stubAirConditioner.Object,
                                  stubFurnace.Object, 
                                  stubSensor.Object);

        temperatureController.AdjustTemperature(73);

        stubAirConditioner.Verify(x => x.On(), Times.Once());
    }

    [Fact]
    public void AdjustTemperature_ShouldCallFurnaceOn()
    {
        var stubSensor = new Mock<TemperatureSensor>();
        stubSensor.SetupProperty(x => x.CurrentTemperature, 73);

        var stubAirConditioner = new Mock<IAirConditioner>();
        var stubFurnace = new Mock<IFurnace>();

        TemperatureController temperatureController = new TemperatureController(stubAirConditioner.Object,
                                                                                stubFurnace.Object,
                                                                                stubSensor.Object);

        temperatureController.AdjustTemperature(75);

        stubFurnace.Verify(x => x.On(), Times.Once());
    }

    [Fact]
    public void AdjustTemperature_ShouldNotCallFurnaceOn()
    {
        var stubSensor = new Mock<TemperatureSensor>();
        stubSensor.SetupProperty(x => x.CurrentTemperature, 75);

        var stubAirConditioner = new Mock<IAirConditioner>();
        var stubFurnace = new Mock<IFurnace>();

        TemperatureController temperatureController = new TemperatureController(stubAirConditioner.Object,
                                                                                stubFurnace.Object,
                                                                                stubSensor.Object);

        temperatureController.AdjustTemperature(73);

        stubFurnace.Verify(x => x.On(), Times.Never());
    }
}
