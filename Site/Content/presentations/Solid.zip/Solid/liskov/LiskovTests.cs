﻿using Example;
using Xunit;

public class LiskovTests
{
    [Fact]
    public void SquareNotARectangle()
    {
        Square square = new Square() { Height = 10, Width = 10 };
        Rectangle rectangle = square;
        rectangle.SetHeight(5);
        rectangle.SetWidth(4);

        int area = rectangle.Height * rectangle.Width;

        Assert.Equal(20, area);
    }
}
