﻿public interface Shape
{
    void Draw();
}
